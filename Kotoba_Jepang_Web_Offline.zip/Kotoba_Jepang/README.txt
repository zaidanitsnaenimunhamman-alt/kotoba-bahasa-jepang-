KOTOBA JEPANG — PAKET APLIKASI WEB OFFLINE

Isi:
- index.html: aplikasi belajar
- manifest.webmanifest: identitas aplikasi untuk pemasangan
- sw.js: cache agar aplikasi dapat dibuka offline setelah pertama kali dimuat
- icon.svg: ikon aplikasi

CARA PAKAI:
1. Ekstrak ZIP ini.
2. Untuk uji cepat, buka index.html di browser. Fungsi belajar berjalan; pemasangan PWA dan cache offline memerlukan hosting HTTPS atau localhost.
3. Agar bisa dipasang sebagai aplikasi dan bekerja offline: unggah isi folder ini ke hosting HTTPS (misalnya GitHub Pages), buka alamatnya di Chrome Android, lalu pilih menu ⋮ > Tambahkan ke layar utama / Install app.
4. Buka sekali saat online agar file tersimpan untuk penggunaan offline.

Catatan: progres kartu, skor terbaik, dan kuis tersimpan di penyimpanan browser perangkat. Paket ini bukan APK.
